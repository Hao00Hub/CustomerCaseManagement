﻿namespace CustomerCaseManagement.Models
{
    public class CustomerCase
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string Contact { get; set; }
        public string Query { get; set; }
        public string Channel { get; set; }
        public string Status { get; set; }
    }
}
