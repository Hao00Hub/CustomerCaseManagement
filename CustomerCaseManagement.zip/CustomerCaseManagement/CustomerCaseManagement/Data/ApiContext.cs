﻿using Microsoft.EntityFrameworkCore;
using CustomerCaseManagement.Models;

namespace CustomerCaseManagement.Data
{
    public class ApiContext : DbContext
    {
        public ApiContext(DbContextOptions<ApiContext> options) : base(options) { }

        public DbSet<CustomerCase> CustomerCases { get; set; }
    


     protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<CustomerCase>().HasData(
                new CustomerCase
                {
                    Id = 1,
                    CustomerName = "John Doe",
                    Contact = "0123456789",
                    Query = "Unable to log in to the account",
                    Channel = "WhatsApp",
                    Status = "Open"
                }
            );
        } 
    }
}
    
