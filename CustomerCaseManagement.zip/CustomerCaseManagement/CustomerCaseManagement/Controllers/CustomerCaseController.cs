﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CustomerCaseManagement.Data;
using CustomerCaseManagement.Models;
using Microsoft.EntityFrameworkCore;


namespace CustomerCaseManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerCaseController : ControllerBase
    {
        private readonly ApiContext _context;

        public CustomerCaseController(ApiContext context)
        {
            _context = context;
        }

        // GET: api/CustomerCase
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CustomerCase>>> GetCustomerCases()
        {
            return await _context.CustomerCases.ToListAsync();
        }

        // GET: api/CustomerCase/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CustomerCase>> GetCustomerCase(int id)
        {
            var customerCase = await _context.CustomerCases.FindAsync(id);

            if (customerCase == null)
            {
                return NotFound();
            }

            return customerCase;
        }

        // POST: api/CustomerCase
        [HttpPost]
        public async Task<ActionResult<CustomerCase>> PostCustomerCase(CustomerCase customerCase)
        {
            _context.CustomerCases.Add(customerCase);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCustomerCase", new { id = customerCase.Id }, customerCase);
        }

        // PUT: api/CustomerCase/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCustomerCase(int id, CustomerCase customerCase)
        {
            if (id != customerCase.Id)
            {
                return BadRequest();
            }

            _context.Entry(customerCase).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/CustomerCase/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCustomerCase(int id)
        {
            var customerCase = await _context.CustomerCases.FindAsync(id);
            if (customerCase == null)
            {
                return NotFound();
            }

            _context.CustomerCases.Remove(customerCase);
            await _context.SaveChangesAsync();

            return NoContent();
        }



    }
}
