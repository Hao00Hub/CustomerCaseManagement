﻿let cases = [];

function loadCases() {
    const searchName = document.getElementById('searchName').value.toLowerCase();
    const channelFilter = document.getElementById('channelFilter').value;

    // Fetch data from the API
    fetch('https://localhost:44301/api/CustomerCase')  // Adjust to your correct backend URL
        .then(response => response.json())
        .then(cases => {
            // Filter the cases based on search and channel
            const filteredCases = cases.filter(caseItem => {
                const matchesName = caseItem.customerName.toLowerCase().includes(searchName);
                const matchesChannel = !channelFilter || caseItem.channel === channelFilter;
                return matchesName && matchesChannel;
            });

            // Clear the current table rows
            const tableBody = document.getElementById('caseTable').getElementsByTagName('tbody')[0];
            tableBody.innerHTML = '';

            // Populate the table with filtered cases
            filteredCases.forEach(caseItem => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${caseItem.id}</td>
                    <td>${caseItem.customerName}</td>
                    <td>${caseItem.contact}</td>
                    <td>${caseItem.query}</td>
                    <td>${caseItem.channel}</td>
                    <td>${caseItem.status}</td>
                    <td>
                        <button onclick="editCase(${caseItem.id})">Edit</button>
                        <button onclick="deleteCase(${caseItem.id})">Delete</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error loading data:', error));
}


function showForm(caseId = null) {
    const form = document.getElementById('caseForm');
    const formTitle = document.getElementById('formTitle');

    // Clear form fields
    document.getElementById('caseId').value = '';
    document.getElementById('customerName').value = '';
    document.getElementById('contact').value = '';
    document.getElementById('query').value = '';
    document.getElementById('channel').value = 'WhatsApp';
    document.getElementById('status').value = 'Open';

    if (caseId) {
        const caseItem = cases.find(c => c.id === caseId);
        document.getElementById('caseId').value = caseItem.id;
        document.getElementById('customerName').value = caseItem.customerName;
        document.getElementById('contact').value = caseItem.contact;
        document.getElementById('query').value = caseItem.query;
        document.getElementById('channel').value = caseItem.channel;
        document.getElementById('status').value = caseItem.status;
        formTitle.textContent = 'Edit Case';
    } else {
        formTitle.textContent = 'Add New Case';
    }

    form.style.display = 'block';
}

function hideForm() {
    document.getElementById('caseForm').style.display = 'none';
}

function saveCase() {
    event.preventDefault();  // Prevent form from refreshing the page

    const caseId = document.getElementById('caseId').value;
    const customerName = document.getElementById('customerName').value;
    const contact = document.getElementById('contact').value;
    const query = document.getElementById('query').value;
    const channel = document.getElementById('channel').value;
    const status = document.getElementById('status').value;

    const caseData = {
        customerName,
        contact,
        query,
        channel,
        status
    };

    if (caseId) {
        // Edit existing case
        fetch(`https://localhost:44301/api/CustomerCase/${caseId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(caseData)
        })
            .then(response => response.json())
            .then(() => {
                loadCases();  // Re-fetch the updated data
                hideForm();   // Hide the form after saving
            })
            .catch(error => console.error('Error editing case:', error));
    } else {
        // Add new case
        fetch('https://localhost:44301/api/CustomerCase', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(caseData)
        })
            .then(response => response.json())
            .then(() => {
                loadCases();  // Re-fetch the updated data
                hideForm();   // Hide the form after saving
            })
            .catch(error => console.error('Error adding case:', error));
    }

}

function editCase(caseId) {
    showForm(caseId);
}

function deleteCase(caseId) {
    fetch(`https://localhost:44301/api/CustomerCase/${caseId}`, {
        method: 'DELETE'
    })
        .then(() => {
            loadCases();  // Re-fetch the updated data
        })
        .catch(error => console.error('Error deleting case:', error));
}

// Initial load
loadCases();
